package com.example.simulador_ir

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
