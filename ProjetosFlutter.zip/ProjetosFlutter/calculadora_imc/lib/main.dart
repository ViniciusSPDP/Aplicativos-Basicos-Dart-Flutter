import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart'; // Importa o pacote de fontes

// A função main() continua a mesma.
void main() {
  runApp(const BMICalculatorApp());
}

// O widget principal agora define nosso novo tema dark.
class BMICalculatorApp extends StatelessWidget {
  const BMICalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora de IMC',
      debugShowCheckedModeBanner: false,
      // A MÁGICA DO DESIGN COMEÇA AQUI!
      theme: ThemeData(
        // Cor de fundo padrão para todo o app.
        scaffoldBackgroundColor: const Color(0xff0a0e21),
        // Define a fonte padrão para toda a aplicação usando Google Fonts.
        textTheme: GoogleFonts.poppinsTextTheme(
          Theme.of(context).textTheme,
        ).apply(bodyColor: Colors.white), // Aplica a cor branca a todo texto
        // Define a cor de destaque que será usada em botões e outros elementos.
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.teal,
        ).copyWith(secondary: Colors.tealAccent),
        // Estilo customizado para os campos de texto.
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xff1d1e33),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide.none,
          ),
          hintStyle: TextStyle(color: Colors.grey.shade600),
          labelStyle: const TextStyle(color: Colors.tealAccent),
        ),
      ),
      home: const BMICalculatorScreen(),
    );
  }
}

// A estrutura do StatefulWidget continua a mesma.
class BMICalculatorScreen extends StatefulWidget {
  const BMICalculatorScreen({super.key});

  @override
  State<BMICalculatorScreen> createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen> {
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  double? _bmi;
  String _resultText = '';
  Color _resultColor = Colors.white; // Nova variável para a cor do resultado

  // A LÓGICA DO CÁLCULO FOI ATUALIZADA PARA DEFINIR A COR
  void _calculateBMI() {
    final String heightText = _heightController.text.replaceAll(',', '.');
    final String weightText = _weightController.text.replaceAll(',', '.');

    final double? height = double.tryParse(heightText);
    final double? weight = double.tryParse(weightText);

    if (height == null || height <= 0 || weight == null || weight <= 0) {
      setState(() {
        _resultText = "Por favor, insira valores válidos.";
        _bmi = null;
      });
      return;
    }

    setState(() {
      _bmi = weight / (height * height);
      if (_bmi! < 18.5) {
        _resultText = 'Abaixo do peso';
        _resultColor = Colors.blue.shade300; // Cor para Abaixo do Peso
      } else if (_bmi! < 25) {
        _resultText = 'Peso normal';
        _resultColor = Colors.green.shade400; // Cor para Peso Normal
      } else if (_bmi! < 30) {
        _resultText = 'Sobrepeso';
        _resultColor = Colors.yellow.shade600; // Cor para Sobrepeso
      } else if (_bmi! < 35) {
        _resultText = 'Obesidade Grau I';
        _resultColor = Colors.orange.shade700; // Cor para Obesidade I
      } else if (_bmi! < 40) {
        _resultText = 'Obesidade Grau II';
        _resultColor = Colors.red.shade600; // Cor para Obesidade II
      } else {
        _resultText = 'Obesidade Grau III';
        _resultColor = Colors.red.shade900; // Cor para Obesidade III
      }
    });
  }

  // O MÉTODO BUILD FOI COMPLETAMENTE REFEITO
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de IMC'),
        backgroundColor: Colors.transparent, // AppBar transparente
        elevation: 0, // Sem sombra
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // Ícone de destaque
            Icon(
              Icons.monitor_weight_outlined,
              size: 120,
              color: Colors.white.withOpacity(0.9),
            ),
            const SizedBox(height: 30),

            // Campo de Altura estilizado
            TextField(
              controller: _heightController,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Altura (m)',
                hintText: 'Ex: 1.75',
                prefixIcon: Icon(Icons.height, color: Colors.tealAccent),
              ),
            ),
            const SizedBox(height: 20),

            // Campo de Peso estilizado
            TextField(
              controller: _weightController,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Peso (kg)',
                hintText: 'Ex: 70.5',
                prefixIcon: Icon(
                  Icons.scale_outlined,
                  color: Colors.tealAccent,
                ),
              ),
            ),
            const SizedBox(height: 40),

            // Botão de Calcular estilizado
            ElevatedButton(
              onPressed: _calculateBMI,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white, // <<< ADICIONE ESTA LINHA
                backgroundColor: Colors.teal, // Cor de fundo
                padding: const EdgeInsets.symmetric(vertical: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                textStyle: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              child: const Text('CALCULAR IMC'),
            ),
            const SizedBox(height: 40),

            // ANIMAÇÃO! O resultado aparece suavemente.
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 500),
              transitionBuilder: (child, animation) {
                return FadeTransition(opacity: animation, child: child);
              },
              child: _bmi == null
                  ? const SizedBox(
                      key: ValueKey('empty'),
                    ) // Chave para animação
                  : _buildResultCard(), // O card de resultado
            ),
          ],
        ),
      ),
    );
  }

  // WIDGET SEPARADO PARA O CARD DE RESULTADO (CÓDIGO MAIS LIMPO)
  Widget _buildResultCard() {
    return Card(
      key: const ValueKey('result'), // Chave para animação
      color: const Color(0xff1d1e33),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              _resultText.toUpperCase(),
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: _resultColor, // A cor dinâmica!
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _bmi!.toStringAsFixed(1),
              style: const TextStyle(
                fontSize: 70,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Valor do seu IMC',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
