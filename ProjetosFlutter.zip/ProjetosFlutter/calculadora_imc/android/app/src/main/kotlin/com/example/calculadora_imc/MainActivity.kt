package com.example.calculadora_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
